export default function DashboardUI({ onLogout }) {
  const numeroNotifiche = 1;

  return (
    <>
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true" />
          <div className="title">
            <h1>Dashboard</h1>
            <span>Monitoraggio Arnie</span>
          </div>
        </div>

        <div className="actions">
          <button
            className="iconbtn"
            type="button"
            aria-label="Notifiche"
            onClick={() => alert("Mockup: centro notifiche")}
          >
            {numeroNotifiche > 0 && <span className="badge">{numeroNotifiche}</span>}
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M18 8a6 6 0 10-12 0c0 7-3 7-3 7h18s-3 0-3-7"></path>
              <path d="M13.73 21a2 2 0 01-3.46 0"></path>
            </svg>
          </button>

          <button
            className="iconbtn"
            type="button"
            aria-label="Esci"
            onClick={() => (onLogout ? onLogout() : null)}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"></path>
              <path d="M16 17l5-5-5-5"></path>
              <path d="M21 12H9"></path>
            </svg>
          </button>
        </div>
      </header>

      <main className="container">
        <section className="alertbar" aria-label="Alert attivi">
          <div className="alert-left">
            <div className="alert-ic" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M10.3 3.7l-8.6 15a2 2 0 001.7 3h17.2a2 2 0 001.7-3l-8.6-15a2 2 0 00-3.4 0z"></path>
                <path d="M12 9v4"></path>
                <path d="M12 17h.01"></path>
              </svg>
            </div>

            <div className="alert-text">
              <div className="main">1 alert attivo</div>
              <div className="sub">Mockup — controlla l’arnia</div>
            </div>
          </div>

          <button className="linkbtn" type="button" onClick={() => alert("Mockup: elenco avvisi")}>
            Vedi
          </button>
        </section>

        <section className="grid" aria-label="Arnie">
          {[1, 2, 3].map((id) => (
            <article key={id} className="card" onClick={() => alert("Mockup: dettaglio Arnia " + id)}>
              <div className="card-inner">
                <div className="row">
                  <div className="hive">Arnia {id}</div>
                  <div className="state-pill">
                    <span className="dot ok" /> OK
                  </div>
                </div>

                <div className="statusline">
                  <div>Stato salute: Buono</div>
                  <div>Criticità: Nessuna</div>
                </div>

                <div className="metrics">
                  <div className="metric">
                    <div className="label">Peso</div>
                    <div className="value">
                      42.3 <span className="unit">kg</span>
                    </div>
                  </div>

                  <div className="metric">
                    <div className="label">Temperatura</div>
                    <div className="value">
                      35.1 <span className="unit">°C</span>
                    </div>
                  </div>

                  <div className="metric">
                    <div className="label">Umidità</div>
                    <div className="value">
                      58 <span className="unit">%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card-footer">
                <span>Ultimo aggiornamento: 6 min fa</span>
                <span className="arrow">Dettagli →</span>
              </div>
            </article>
          ))}
        </section>
      </main>
    </>
  );
}
