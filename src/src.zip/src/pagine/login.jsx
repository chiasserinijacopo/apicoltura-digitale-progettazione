import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [apiKey, setApiKey] = useState("");
  const [mostra, setMostra] = useState(false);
  const [errore, setErrore] = useState("");

  function onLogin() {
    const v = (apiKey || "").trim();

    if (!v) {
      setErrore("Inserisci una API key.");
      return;
    }
    if (!v.startsWith("RIGON-ARNIA-")) {
      setErrore("API key non valida.");
      return;
    }

    setErrore("");
    navigate("/dashboard");
  }

  return (
    <div className="login-page">
      <div className="wrap">
        <div className="brand-login">
          <div className="logo" aria-hidden="true" />
          <h1>Apicoltura Digitale</h1>
        </div>

        <div className="login-card">
          <h2 className="title">Accesso</h2>
          <p className="subtitle">
            Inserisci la API key dell’arnia per aprire la dashboard.
          </p>

          <label htmlFor="apikey">API Key</label>

          <div className="field">
            <input
              id="apikey"
              type={mostra ? "text" : "password"}
              autoComplete="off"
              placeholder="RIGON-ARNIA-1-••••••••"
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setErrore("");
              }}
            />

            <button
              className="iconbtn"
              id="toggle"
              type="button"
              aria-label="Mostra/Nascondi"
              onClick={() => setMostra((s) => !s)}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
            </button>
          </div>

          <button className="btn" type="button" onClick={onLogin}>
            Login
          </button>

          <div className={"status" + (errore ? " show err" : "")}>
            {errore}
          </div>
        </div>

        <div className="hint">
          Esempio: <code>RIGON-ARNIA-1-9F2A</code>
        </div>
      </div>
    </div>
  );
}
