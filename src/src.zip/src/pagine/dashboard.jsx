import { useNavigate } from "react-router-dom";
import DashboardUI from "../components/dashboard/DashboardUI.jsx";

export default function DashboardPage() {
  const navigate = useNavigate();
  return <DashboardUI onLogout={() => navigate("/login")} />;
}
