import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [apiKey, setApiKey] = useState("");
  const [mostra, setMostra] = useState(false);
  const [errore, setErrore] = useState("");

  const placeholder = useMemo(() => "RIGON-ARNIA-1-9F2A", []);

  function onLogin() {
    const v = (apiKey || "").trim();

    if (!v) return setErrore("Inserisci una API key.");
    if (!v.startsWith("RIGON-ARNIA-")) return setErrore("API key non valida.");

    setErrore("");
    navigate("/dashboard");
  }

  return (
    <div className="page page-center">
      <div className="phone authShell">
        <div className="authTop">
          <div className="brandMark big" aria-hidden="true">
            <span className="brandDot" />
          </div>
          <div className="authTitle">Apicoltura Digitale</div>
          <div className="muted">Accedi per monitorare le tue arnie.</div>
        </div>

        <div className="card authCard">
          <div className="h2">Accesso</div>
          <div className="muted">Inserisci la tua API Key.</div>

          <div className="field mt">
            <div className="label">API Key</div>
            <div className="inputWithBtn">
              <input
                className="input"
                type={mostra ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={placeholder}
              />
              <button className="btn ghost smallBtn" type="button" onClick={() => setMostra((s) => !s)}>
                {mostra ? "Nascondi" : "Mostra"}
              </button>
            </div>
            {errore ? <div className="error">{errore}</div> : <div className="help">Esempio: {placeholder}</div>}
          </div>

          <button className="btn mt" type="button" onClick={onLogin}>
            Entra
          </button>

          <button className="btn ghost mt" type="button" onClick={() => alert("Mockup: recupero API key")}>
            Non ho la chiave
          </button>
        </div>

        <div className="authFoot muted small">v0.1 • UI mockup</div>
      </div>
    </div>
  );
}
