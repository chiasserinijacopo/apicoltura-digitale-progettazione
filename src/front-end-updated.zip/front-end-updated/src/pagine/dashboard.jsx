import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

function statusMeta(stato) {
  if (stato === "Critica") return { cls: "badge danger", dot: "dot danger" };
  if (stato === "Attenzione") return { cls: "badge warn", dot: "dot warn" };
  return { cls: "badge ok", dot: "dot ok" };
}

export default function DashboardPrincipale() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const arnie = useMemo(
    () => [
      { id: 1, nome: "Arnia 1 • Frutteto", stato: "OK", salute: "Buono", criticita: "Nessuna", last: "2 min fa" },
      { id: 2, nome: "Arnia 2 • Collina", stato: "Attenzione", salute: "Da controllare", criticita: "Media", last: "8 min fa" },
      { id: 3, nome: "Arnia 3 • Bosco", stato: "Critica", salute: "Allarme", criticita: "Alta", last: "1 min fa" },
    ],
    []
  );

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return arnie;
    return arnie.filter((a) => (a.nome + " " + a.id).toLowerCase().includes(s));
  }, [arnie, q]);

  return (
    <div className="stack">
      <div className="card hero">
        <div className="h1">Ciao 👋</div>
        <div className="muted">Seleziona un’arnia per vedere grafici, soglie e notifiche.</div>

        <div className="searchRow">
          <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cerca arnia…" />
          <button className="btn ghost" type="button" onClick={() => alert("Mockup: scan QR")}>
            QR
          </button>
        </div>
      </div>

      <div className="listCard">
        {filtered.map((a) => {
          const meta = statusMeta(a.stato);
          return (
            <button key={a.id} className="hiveCard" type="button" onClick={() => navigate(`/arnia/${a.id}`)}>
              <div className="hiveTop">
                <div className="hiveName">{a.nome}</div>
                <span className={meta.cls}><span className={meta.dot} />{a.stato}</span>
              </div>

              <div className="gridInfo">
                <div className="infoItem">
                  <div className="k">Salute</div>
                  <div className="v">{a.salute}</div>
                </div>
                <div className="infoItem">
                  <div className="k">Criticità</div>
                  <div className="v">{a.criticita}</div>
                </div>
                <div className="infoItem">
                  <div className="k">Aggiornamento</div>
                  <div className="v">{a.last}</div>
                </div>
              </div>

              <div className="hiveGo">Apri →</div>
            </button>
          );
        })}
      </div>

      <button className="fab" type="button" onClick={() => navigate("/aggiungi")} aria-label="Aggiungi arnia">
        +
      </button>
    </div>
  );
}
