import { useMemo, useState } from "react";
import MiniChart from "../components/ui/MiniChart.jsx";

function StatCard({ label, value, note }) {
  return (
    <div className="statCard">
      <div className="statLabel">{label}</div>
      <div className="statValue">{value}</div>
      {note ? <div className="statNote">{note}</div> : null}
    </div>
  );
}

export default function Insights() {
  const [range, setRange] = useState("7g");

  const data = useMemo(() => {
    if (range === "24h") return { peso: [18, 19, 18, 20, 21, 20], temp: [30, 32, 31, 33, 34, 33], um: [48, 50, 52, 49, 51, 53] };
    if (range === "30g") return { peso: [12, 13, 14, 16, 18, 20], temp: [26, 27, 28, 30, 31, 32], um: [42, 45, 44, 48, 50, 52] };
    return { peso: [14, 15, 16, 18, 19, 21], temp: [28, 29, 30, 31, 33, 34], um: [40, 44, 46, 45, 47, 49] };
  }, [range]);

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Panoramica</div>
            <div className="muted">Andamento medio su tutte le arnie.</div>
          </div>
          <div className="segmented" role="tablist" aria-label="Intervallo dati">
            <button className={"seg" + (range === "24h" ? " active" : "")} onClick={() => setRange("24h")} type="button">24h</button>
            <button className={"seg" + (range === "7g" ? " active" : "")} onClick={() => setRange("7g")} type="button">7g</button>
            <button className={"seg" + (range === "30g" ? " active" : "")} onClick={() => setRange("30g")} type="button">30g</button>
          </div>
        </div>
      </div>

      <div className="grid2">
        <StatCard label="Arnie online" value="3/3" note="Ultimo sync: 2 min fa" />
        <StatCard label="Stato generale" value="Buono" note="1 attenzione • 1 critico" />
      </div>

      <div className="panelCard">
        <div className="panelHeadRow">
          <div className="panelTitle">Peso (Kg)</div>
          <div className="pillSoft">trend</div>
        </div>
        <MiniChart points={data.peso} height={110} />
      </div>

      <div className="grid2">
        <div className="panelCard">
          <div className="panelHeadRow">
            <div className="panelTitle">Temperatura (°C)</div>
            <div className="pillSoft">media</div>
          </div>
          <MiniChart points={data.temp} height={95} />
        </div>
        <div className="panelCard">
          <div className="panelHeadRow">
            <div className="panelTitle">Umidità (%)</div>
            <div className="pillSoft">media</div>
          </div>
          <MiniChart points={data.um} height={95} />
        </div>
      </div>
    </div>
  );
}
