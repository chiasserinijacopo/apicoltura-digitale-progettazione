import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AggiungiArnia() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [key, setKey] = useState("");

  const placeholder = useMemo(() => "ARNIA-NUOVA-01", []);

  function onSave() {
    if (!name.trim()) return alert("Inserisci un nome per l’arnia.");
    alert("Mockup: arnia aggiunta!");
    navigate("/dashboard");
  }

  return (
    <div className="stack">
      <div className="card">
        <div className="h2">Aggiungi una nuova arnia</div>
        <div className="muted">Collega un dispositivo e scegli un nome riconoscibile.</div>
      </div>

      <div className="card">
        <div className="field">
          <div className="label">Nome arnia</div>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Es. Arnia 4 - Bosco" />
        </div>

        <div className="field">
          <div className="label">Posizione</div>
          <input className="input" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Es. Via Roma, 12 • Rovereto" />
        </div>

        <div className="field">
          <div className="label">Chiave dispositivo</div>
          <input className="input" value={key} onChange={(e) => setKey(e.target.value)} placeholder={placeholder} />
          <div className="help">La chiave viene fornita sul dispositivo o nella confezione.</div>
        </div>

        <div className="rowGap">
          <button className="btn" type="button" onClick={onSave}>Salva</button>
          <button className="btn ghost" type="button" onClick={() => navigate(-1)}>Annulla</button>
        </div>
      </div>
    </div>
  );
}
