import { useMemo } from "react";
import { useNavigate } from "react-router-dom";

function severityMeta(level) {
  if (level === "critico") return { label: "Critico", cls: "badge danger" };
  if (level === "attenzione") return { label: "Attenzione", cls: "badge warn" };
  return { label: "Info", cls: "badge ok" };
}

export default function Alerts() {
  const navigate = useNavigate();

  const items = useMemo(
    () => [
      { id: 1, level: "critico", title: "Temperatura troppo alta", body: "Arnia 3 ha superato la soglia massima.", when: "Oggi • 14:12", hive: 3 },
      { id: 2, level: "attenzione", title: "Calo di peso improvviso", body: "Possibile sciamatura o raccolta intensa.", when: "Oggi • 09:31", hive: 2 },
      { id: 3, level: "info", title: "Batteria ricaricata", body: "Arnia 1 ha raggiunto il 85%.", when: "Ieri • 18:05", hive: 1 },
      { id: 4, level: "info", title: "Sincronizzazione completata", body: "Dati aggiornati correttamente.", when: "2 giorni fa • 07:44", hive: 1 },
    ],
    []
  );

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Centro avvisi</div>
            <div className="muted">Tieni d’occhio le anomalie e gli eventi recenti.</div>
          </div>
          <button className="btn ghost" type="button" onClick={() => alert("Mockup: filtro avvisi")}>
            Filtra
          </button>
        </div>
      </div>

      <div className="listCard">
        {items.map((n) => {
          const meta = severityMeta(n.level);
          return (
            <button key={n.id} className="notifRow" type="button" onClick={() => navigate(`/arnia/${n.hive}`)}>
              <div className="notifTop">
                <span className={meta.cls}>{meta.label}</span>
                <span className="muted small">{n.when}</span>
              </div>
              <div className="notifTitle">{n.title}</div>
              <div className="notifBody">{n.body}</div>
              <div className="notifFoot">Apri Arnia {n.hive} →</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
