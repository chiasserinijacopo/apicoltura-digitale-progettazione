import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ImpostazioniApp() {
  const navigate = useNavigate();
  const [notifiche, setNotifiche] = useState(true);
  const [dark, setDark] = useState(true);

  return (
    <div className="stack">
      <div className="card">
        <div className="h2">Preferenze</div>
        <div className="muted">Personalizza l’esperienza dell’app.</div>
      </div>

      <div className="card">
        <div className="sectionLabel">Account</div>

        <button className="rowBtn" type="button" onClick={() => alert("Mockup: Profilo utente")}>
          <span>Profilo utente</span>
          <span className="chev">›</span>
        </button>

        <div className="divider" />

        <button className="rowBtn" type="button" onClick={() => alert("Mockup: sicurezza")}>
          <span>Sicurezza</span>
          <span className="chev">›</span>
        </button>
      </div>

      <div className="card">
        <div className="sectionLabel">Sistema</div>

        <label className="toggleRow">
          <span className="toggleText">
            <span className="rowTitle">Notifiche</span>
            <span className="muted small">Ricevi avvisi e promemoria.</span>
          </span>
          <input type="checkbox" checked={notifiche} onChange={(e) => setNotifiche(e.target.checked)} />
          <span className="toggleUI" aria-hidden="true" />
        </label>

        <div className="divider" />

        <label className="toggleRow">
          <span className="toggleText">
            <span className="rowTitle">Tema scuro</span>
            <span className="muted small">Mockup: toggle tema.</span>
          </span>
          <input type="checkbox" checked={dark} onChange={(e) => setDark(e.target.checked)} />
          <span className="toggleUI" aria-hidden="true" />
        </label>
      </div>

      <div className="card">
        <div className="sectionLabel">Azioni</div>
        <button className="btn danger" type="button" onClick={() => navigate("/login")}>Esci</button>
        <div className="help">Nota: in questo mockup il logout riporta alla schermata di accesso.</div>
      </div>
    </div>
  );
}
