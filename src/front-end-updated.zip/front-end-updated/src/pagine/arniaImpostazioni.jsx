import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function Stepper({ value, onChange, min = 0, max = 100, unit = "" }) {
  return (
    <div className="stepper">
      <button className="stepBtn" type="button" onClick={() => onChange(Math.max(min, value - 1))} aria-label="Diminuisci">–</button>
      <div className="stepValue">
        {value}
        <span className="stepUnit">{unit}</span>
      </div>
      <button className="stepBtn" type="button" onClick={() => onChange(Math.min(max, value + 1))} aria-label="Aumenta">+</button>
    </div>
  );
}

export default function ArniaImpostazioni() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [tMin, setTMin] = useState(18);
  const [tMax, setTMax] = useState(25);
  const [bat, setBat] = useState(20);
  const [pesoMax, setPesoMax] = useState(50);
  const [notifiche, setNotifiche] = useState(true);

  function onSave() {
    alert("Mockup: soglie salvate!");
    navigate(`/arnia/${id}`);
  }

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Soglie & sensori</div>
            <div className="muted">Arnia {id} • imposta i limiti per gli avvisi.</div>
          </div>
          <button className="btn ghost" type="button" onClick={() => navigate(`/arnia/${id}`)}>Chiudi</button>
        </div>
      </div>

      <div className="card">
        <div className="sectionLabel">Temperatura</div>

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Minima</div>
            <div className="muted small">Sotto questa soglia ricevi un avviso.</div>
          </div>
          <Stepper value={tMin} onChange={setTMin} min={0} max={40} unit="°C" />
        </div>

        <div className="divider" />

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Massima</div>
            <div className="muted small">Sopra questa soglia ricevi un avviso.</div>
          </div>
          <Stepper value={tMax} onChange={setTMax} min={0} max={60} unit="°C" />
        </div>
      </div>

      <div className="card">
        <div className="sectionLabel">Peso</div>

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Massimo</div>
            <div className="muted small">Per rilevare accumuli anomali.</div>
          </div>
          <Stepper value={pesoMax} onChange={setPesoMax} min={0} max={120} unit="Kg" />
        </div>
      </div>

      <div className="card">
        <div className="sectionLabel">Batteria</div>

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Soglia minima</div>
            <div className="muted small">Ricevi un avviso quando scende sotto.</div>
          </div>
          <Stepper value={bat} onChange={setBat} min={0} max={100} unit="%" />
        </div>

        <div className="divider" />

        <label className="toggleRow">
          <span className="toggleText">
            <span className="rowTitle">Notifiche</span>
            <span className="muted small">Attiva/disattiva gli avvisi per questa arnia.</span>
          </span>
          <input type="checkbox" checked={notifiche} onChange={(e) => setNotifiche(e.target.checked)} />
          <span className="toggleUI" aria-hidden="true" />
        </label>
      </div>

      <div className="rowGap">
        <button className="btn" type="button" onClick={onSave}>Salva</button>
        <button className="btn ghost" type="button" onClick={() => navigate(-1)}>Annulla</button>
      </div>
    </div>
  );
}
