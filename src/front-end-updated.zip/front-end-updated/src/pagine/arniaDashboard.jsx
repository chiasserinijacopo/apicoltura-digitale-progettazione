import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import MiniChart from "../components/ui/MiniChart.jsx";

function MetricCard({ title, unit, points, foot }) {
  return (
    <div className="panelCard">
      <div className="panelHeadRow">
        <div className="panelTitle">{title} <span className="panelUnit">{unit}</span></div>
        <div className="pillSoft">trend</div>
      </div>
      <MiniChart points={points} height={110} />
      {foot ? <div className="panelFoot">{foot}</div> : null}
    </div>
  );
}

export default function ArniaDashboard() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [tab, setTab] = useState("settimana");

  const data = useMemo(() => {
    if (tab === "oggi") {
      return { peso: [18, 22, 21, 24, 23, 26], temp: [30, 33, 32, 34, 33, 35], um: [45, 55, 52, 58, 54, 60] };
    }
    if (tab === "mese") {
      return { peso: [12, 16, 15, 20, 19, 24], temp: [26, 29, 28, 31, 30, 33], um: [40, 48, 46, 55, 52, 62] };
    }
    return { peso: [14, 20, 18, 22, 19, 27], temp: [28, 34, 31, 35, 33, 36], um: [35, 52, 46, 50, 48, 58] };
  }, [tab]);

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Arnia {id}</div>
            <div className="muted">Posizione: <span className="pillSoft">[Location]</span></div>
          </div>
          <button className="btn" type="button" onClick={() => navigate(`/arnia/${id}/impostazioni`)}>
            Soglie
          </button>
        </div>

        <div className="segmented mt">
          <button className={"seg" + (tab === "oggi" ? " active" : "")} onClick={() => setTab("oggi")} type="button">Oggi</button>
          <button className={"seg" + (tab === "settimana" ? " active" : "")} onClick={() => setTab("settimana")} type="button">Settimana</button>
          <button className={"seg" + (tab === "mese" ? " active" : "")} onClick={() => setTab("mese")} type="button">Mese</button>
        </div>
      </div>

      <MetricCard title="Peso" unit="Kg" points={data.peso} foot="Suggerimento: controlla variazioni improvvise > 2Kg." />
      <div className="grid2">
        <MetricCard title="Temperatura" unit="°C" points={data.temp} />
        <MetricCard title="Umidità" unit="%" points={data.um} />
      </div>

      <div className="listCard">
        <div className="listHeader">
          <div className="h3">Ultimi eventi</div>
          <button className="btn ghost" type="button" onClick={() => navigate("/alerts")}>Vedi tutti</button>
        </div>

        <div className="notifMini">
          <div className="miniItem">
            <span className="badge danger">Critico</span>
            <div className="miniText">Temperatura massima superata</div>
            <div className="muted small">Oggi • 14:12</div>
          </div>
          <div className="miniItem">
            <span className="badge warn">Attenzione</span>
            <div className="miniText">Calo di peso improvviso</div>
            <div className="muted small">Oggi • 09:31</div>
          </div>
          <div className="miniItem">
            <span className="badge ok">Info</span>
            <div className="miniText">Batteria ricaricata</div>
            <div className="muted small">Ieri • 18:05</div>
          </div>
        </div>
      </div>
    </div>
  );
}
