export default function TopBar({ notifCount }) {
  return (
    <header className="bg-[#121212] border-b border-[#2A2A2A] px-4 py-4 flex justify-between items-center">
      <div>
        <h1 className="text-xl font-bold text-white">Dashboard</h1>
        <p className="text-xs text-gray-400">Monitoraggio Arnie • Tema Arnia</p>
      </div>

      <div className="relative">
        <button className="p-2 bg-[#1E1E1E] rounded-lg text-white">
          🔔
        </button>
        {notifCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-xs w-5 h-5 flex items-center justify-center rounded-full">
            {notifCount}
          </span>
        )}
      </div>
    </header>
  );
}
