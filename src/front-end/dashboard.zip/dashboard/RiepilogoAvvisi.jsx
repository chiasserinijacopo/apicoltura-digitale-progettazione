export default function AlertSummary({ total, critical, warning }) {
  return (
    <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-4 flex justify-between items-center">
      <div>
        <h2 className="text-white font-semibold">
          {total} alert attivi
        </h2>
        <p className="text-sm text-gray-400">
          {critical} critico · {warning} avviso
        </p>
      </div>

      <button className="bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold">
        Vedi
      </button>
    </div>
  );
}
