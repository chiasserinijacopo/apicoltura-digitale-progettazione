import IndicatoreStato from "./IndicatoreStato.jsx";
import RiquadroMetrica from "./RiquadroMetrica.jsx";

export default function SchedaArnia({ arnia, hive, onClick }) {
  // compatibilità: accetta sia "arnia" (italiano) sia "hive" (inglese)
  const dato = arnia || hive;

  return (
    <div
      onClick={onClick}
      className="bg-[#121212] border border-[#2A2A2A] rounded-xl p-4 cursor-pointer hover:border-yellow-400 transition"
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg text-white font-semibold">{dato.nome || dato.name}</h3>
        <IndicatoreStato stato={dato.stato || dato.status} />
      </div>

      <div className="grid grid-cols-3 gap-3 pb-3 border-b border-[#2A2A2A]">
        <RiquadroMetrica label="Peso" value={dato.peso ?? dato.weight} unit="kg" />
        <RiquadroMetrica label="Temp" value={dato.temperatura ?? dato.temperature} unit="°C" />
        <RiquadroMetrica label="Umidità" value={dato.umidita ?? dato.humidity} unit="%" />
      </div>

      <p className="text-xs text-gray-400 mt-3">
        Ultimo aggiornamento: {dato.ultimoAggiornamento || dato.lastUpdate}
      </p>

      <p className="text-xs text-yellow-400 mt-2 font-semibold">
        Apri →
      </p>
    </div>
  );
}
