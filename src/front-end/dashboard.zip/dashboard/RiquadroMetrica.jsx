export default function MetricBox({ label, value, unit }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-white font-semibold">
        {value}
        <span className="text-gray-400 text-sm ml-1">{unit}</span>
      </p>
    </div>
  );
}
