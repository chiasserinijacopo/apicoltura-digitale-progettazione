export default function StatusPill({ status }) {
  const map = {
    ok: "bg-green-500/10 text-green-400",
    warning: "bg-yellow-500/10 text-yellow-400",
    critical: "bg-red-500/10 text-red-400",
  };

  const label = {
    ok: "OK",
    warning: "Attenzione",
    critical: "Critica",
  };

  return (
    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${map[status]}`}>
      {label[status]}
    </span>
  );
}
