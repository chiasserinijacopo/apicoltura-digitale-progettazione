import { NavLink, Outlet, useLocation, useNavigate, matchPath } from "react-router-dom";

function Icon({ name }) {
  // Simple inline icons (no deps)
  const common = { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "home":
      return (
        <svg {...common}>
          <path d="M3 10.5 12 3l9 7.5" />
          <path d="M5 9.5V21h14V9.5" />
        </svg>
      );
    case "bell":
      return (
        <svg {...common}>
          <path d="M18 8a6 6 0 10-12 0c0 7-3 7-3 7h18s-3 0-3-7" />
          <path d="M13.73 21a2 2 0 01-3.46 0" />
        </svg>
      );
    case "chart":
      return (
        <svg {...common}>
          <path d="M3 3v18h18" />
          <path d="M7 14l3-3 3 3 5-7" />
        </svg>
      );
    case "settings":
      return (
        <svg {...common}>
          <path d="M12 15.5a3.5 3.5 0 100-7 3.5 3.5 0 000 7z" />
          <path d="M19.4 15a1.8 1.8 0 00.36 1.98l.06.06-1.6 2.77-.08-.03a1.9 1.9 0 00-2.08.5l-.05.05-2.77-1.6.03-.08a1.9 1.9 0 00-.5-2.08l-.05-.05 1.6-2.77.08.03a1.9 1.9 0 002.08-.5l.05-.05 2.77 1.6-.03.08z" opacity=".0" />
          <path d="M19 12a7 7 0 00-.08-1l2.03-1.58-2-3.46-2.45 1a7.2 7.2 0 00-1.7-1L14.5 3h-4L9.2 5a7.2 7.2 0 00-1.7 1l-2.45-1-2 3.46L5.08 11A7 7 0 005 12c0 .34.03.67.08 1l-2.03 1.58 2 3.46 2.45-1c.52.42 1.09.77 1.7 1L10.5 21h4l1.3-2.0c.61-.23 1.18-.58 1.7-1l2.45 1 2-3.46L18.92 13c.05-.33.08-.66.08-1z" />
        </svg>
      );
    case "back":
      return (
        <svg {...common}>
          <path d="M15 18l-6-6 6-6" />
        </svg>
      );
    default:
      return null;
  }
}

function useTitle() {
  const { pathname } = useLocation();

  const arnia = matchPath("/arnia/:id/*", pathname);
  if (arnia?.params?.id) return `Arnia ${arnia.params.id}`;

  const map = {
    "/dashboard": "Le tue arnie",
    "/alerts": "Avvisi",
    "/insights": "Statistiche",
    "/impostazioni": "Impostazioni",
    "/aggiungi": "Aggiungi arnia",
  };

  return map[pathname] || "Apicoltura Digitale";
}

function isRootTab(pathname) {
  return ["/dashboard", "/alerts", "/insights", "/impostazioni"].includes(pathname);
}

export default function AppShell() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const title = useTitle();

  const showBack = !isRootTab(pathname);

  return (
    <div className="page">
      <div className="phone appShell">
        <header className="appBar">
          <div className="appBarLeft">
            {showBack ? (
              <button
                className="iconBtn"
                type="button"
                onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/dashboard"))}
                aria-label="Indietro"
              >
                <Icon name="back" />
              </button>
            ) : (
              <div className="brandMark" aria-hidden="true">
                <span className="brandDot" />
              </div>
            )}
          </div>

          <div className="appBarTitle">
            <div className="appBarTitleTop">{title}</div>
            <div className="appBarTitleSub">Monitoraggio arnie</div>
          </div>

          <div className="appBarRight">
            <button className="iconBtn" type="button" onClick={() => navigate("/impostazioni")} aria-label="Impostazioni">
              <Icon name="settings" />
            </button>
          </div>
        </header>

        <main className="appContent" aria-live="polite">
          {/*
            Light route transitions without introducing new deps.
            Keying the wrapper forces remount so CSS animations replay.
          */}
          <div key={pathname} className="routeEnter">
            <Outlet />
          </div>
        </main>

        <nav className="tabBar" aria-label="Navigazione principale">
          <NavLink to="/dashboard" className={({ isActive }) => "tabItem" + (isActive ? " active" : "")}>
            <span className="tabIcon"><Icon name="home" /></span>
            <span className="tabLabel">Home</span>
          </NavLink>

          <NavLink to="/alerts" className={({ isActive }) => "tabItem" + (isActive ? " active" : "")}>
            <span className="tabIcon"><Icon name="bell" /></span>
            <span className="tabLabel">Avvisi</span>
          </NavLink>

          <NavLink to="/insights" className={({ isActive }) => "tabItem" + (isActive ? " active" : "")}>
            <span className="tabIcon"><Icon name="chart" /></span>
            <span className="tabLabel">Dati</span>
          </NavLink>

          <NavLink to="/impostazioni" className={({ isActive }) => "tabItem" + (isActive ? " active" : "")}>
            <span className="tabIcon"><Icon name="settings" /></span>
            <span className="tabLabel">Altro</span>
          </NavLink>
        </nav>
      </div>
    </div>
  );
}
