function statusFromHive(h) {
  // euristica semplice: se arn_piena true => attenzione
  // se manca => ok
  const piena = h?.arn_piena === true || h?.arn_piena === "true";
  if (piena) return { stato: "Attenzione", dot: "warn", salute: "Da controllare", criticita: "Media" };
  return { stato: "OK", dot: "ok", salute: "Buono", criticita: "Nessuna" };
}

export default function DashboardUI({ onLogout, onApriImpostazioni, onApriArnia, arnie = [], loading = false, error = "" }) {
  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Le tue arnie</div>
            <div className="muted">Seleziona un’arnia per aprire la scheda.</div>
          </div>

          <button className="btn ghost" type="button" onClick={() => onApriImpostazioni?.()} aria-label="Impostazioni App">
            Impostazioni
          </button>
        </div>
      </div>

      {error ? (
        <div className="card">
          <div className="muted" style={{ color: "#ff6b6b" }}>{error}</div>
        </div>
      ) : null}

      <div className="listCard">
        {loading ? (
          <div className="emptyState">Caricamento…</div>
        ) : arnie.length ? (
          arnie.map((h) => {
            const meta = statusFromHive(h);
            const name = h?.arn_nome || h?.arn_MacAddress || `Arnia ${h?._id?.slice?.(0, 6) || ""}`;
            const subtitle = h?.arn_dataInst ? `Installata: ${String(h.arn_dataInst).slice(0, 10)}` : "";

            return (
              <button key={h._id || h.id} type="button" className="dashCard" onClick={() => onApriArnia?.(h._id || h.id)}>
                <div className="dashCardTop">
                  <div className="dashName">{name}</div>
                  <div className="dashPill">
                    <span className={`dot ${meta.dot}`} />
                    {meta.stato}
                  </div>
                </div>

                {subtitle ? <div className="muted small" style={{ marginTop: 6 }}>{subtitle}</div> : null}

                <div className="dashRow">
                  <span className="muted">Salute</span>
                  <span>{meta.salute}</span>
                </div>
                <div className="dashRow">
                  <span className="muted">Criticità</span>
                  <span>{meta.criticita}</span>
                </div>

                <div className="dashGo">Apri →</div>
              </button>
            );
          })
        ) : (
          <div className="emptyState">
            Nessuna arnia trovata.
            <div className="muted small" style={{ marginTop: 8 }}>
              Se è la prima volta, aggiungine una dalla schermata “+”.
            </div>
          </div>
        )}
      </div>

      <button className="logoutBtn" type="button" onClick={() => onLogout?.()}>
        Esci
      </button>
    </div>
  );
}
