import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { restdbPost } from "../lib/restdb.js";

export default function AggiungiArnia() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [key, setKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(""
  );

  const placeholder = useMemo(() => "ce:d3:00:6a:c4:9e", []);

  async function onSave() {
    setError("");
    if (!name.trim()) return setError("Inserisci un nome per l’arnia.");
    if (!key.trim()) return setError("Inserisci il MAC Address / chiave dispositivo.");

    setLoading(true);
    try {
      await restdbPost("arnie", {
        arn_dataInst: new Date().toISOString().slice(0, 10),
        arn_piena: false,
        arn_MacAddress: key.trim(),
        // campi extra utili per la UI (RestDB li accetta se non hai vincoli rigidi)
        arn_nome: name.trim(),
        arn_posizione: location.trim(),
      });
      navigate("/dashboard");
    } catch (e) {
      setError(e?.message || "Errore durante il salvataggio.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="stack">
      <div className="card">
        <div className="h2">Aggiungi una nuova arnia</div>
        <div className="muted">Crea una nuova arnia nel database e collegala al dispositivo.</div>
      </div>

      <div className="card">
        <div className="field">
          <div className="label">Nome arnia</div>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Es. Arnia 4 - Bosco" />
        </div>

        <div className="field">
          <div className="label">Posizione</div>
          <input className="input" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Es. Apiario Collina" />
        </div>

        <div className="field">
          <div className="label">MAC Address dispositivo</div>
          <input className="input" value={key} onChange={(e) => setKey(e.target.value)} placeholder={placeholder} />
          <div className="help">Nel DB il campo è <code>arn_MacAddress</code>.</div>
        </div>

        {error ? <div className="statusX show err">{error}</div> : null}

        <div className="rowGap">
          <button className="btn" type="button" onClick={onSave} disabled={loading}>
            {loading ? "Salvataggio…" : "Salva"}
          </button>
          <button className="btn ghost" type="button" onClick={() => navigate(-1)} disabled={loading}>Annulla</button>
        </div>
      </div>
    </div>
  );
}
