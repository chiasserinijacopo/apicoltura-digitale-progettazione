import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { restdbGet } from "../lib/restdb.js";

function severityMeta(title) {
  const t = String(title || "").toLowerCase();
  if (t.includes("crit") || t.includes("allarme") || t.includes("troppo") || t.includes("superat")) return { label: "Critico", cls: "badge danger" };
  if (t.includes("atten") || t.includes("warn") || t.includes("cala") || t.includes("basso") || t.includes("alto")) return { label: "Attenzione", cls: "badge warn" };
  return { label: "Info", cls: "badge ok" };
}

export default function Alerts() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    async function run() {
      setLoading(true);
      setError("");
      try {
        const data = await restdbGet("notifiche", {
          h: { $orderby: { not_dataOra: -1, not_data: -1 }, $max: 50 },
        });
        if (!alive) return;
        setItems(Array.isArray(data) ? data : []);
      } catch (e) {
        if (!alive) return;
        setError(e?.message || "Errore caricamento notifiche");
      } finally {
        if (alive) setLoading(false);
      }
    }
    run();
    return () => {
      alive = false;
    };
  }, []);

  const view = useMemo(() => {
    return items.map((n) => {
      const when = n.not_dataOra || n.not_data || n.createdAt;
      const m = severityMeta(n.not_titolo || n.title);
      return {
        id: n._id || n.id,
        title: n.not_titolo || n.title || "Notifica",
        body: n.not_desc || n.not_dex || n.body || "",
        when: when ? new Date(when).toLocaleString() : "",
        meta: m,
        raw: n,
      };
    });
  }, [items]);

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Centro avvisi</div>
            <div className="muted">Eventi e anomalie dal database.</div>
          </div>
          <button className="btn ghost" type="button" onClick={() => window.location.reload()}>
            Aggiorna
          </button>
        </div>
      </div>

      {loading ? (
        <div className="card"><div className="muted">Caricamento…</div></div>
      ) : error ? (
        <div className="card"><div className="h3">Errore</div><div className="muted" style={{ marginTop: 6 }}>{error}</div></div>
      ) : (
        <div className="listCard">
          {view.length ? (
            view.map((n) => (
              <button key={n.id} className="notifRow" type="button" onClick={() => navigate("/dashboard")}>
                <div className="notifTop">
                  <span className={n.meta.cls}>{n.meta.label}</span>
                  <span className="muted small">{n.when}</span>
                </div>
                <div className="notifTitle">{n.title}</div>
                {n.body ? <div className="notifBody">{n.body}</div> : null}
                <div className="notifFoot">Apri dashboard →</div>
              </button>
            ))
          ) : (
            <div className="emptyState">Nessuna notifica trovata.</div>
          )}
        </div>
      )}
    </div>
  );
}
