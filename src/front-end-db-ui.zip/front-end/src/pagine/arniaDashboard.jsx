import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import MiniChart from "../components/ui/MiniChart.jsx";
import { restdbGet } from "../lib/restdb.js";

function MetricCard({ title, unit, points, foot }) {
  return (
    <div className="panelCard">
      <div className="panelHeadRow">
        <div className="panelTitle">
          {title} <span className="panelUnit">{unit}</span>
        </div>
        <div className="pillSoft">trend</div>
      </div>
      <MiniChart points={points} height={110} />
      {foot ? <div className="panelFoot">{foot}</div> : null}
    </div>
  );
}

function parseTime(r) {
  // Prefer ril_dataOra (ISO) se presente
  const iso = r?.ril_dataOra || r?.ril_data || r?.createdAt;
  if (!iso) return null;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

function pickTypeLabel(desc) {
  const s = (desc || "").toLowerCase();
  if (s.includes("peso")) return "peso";
  if (s.includes("temp")) return "temp";
  if (s.includes("umid")) return "um";
  if (s.includes("acqua") || s.includes("water")) return "acqua";
  if (s.includes("rumore") || s.includes("suono")) return "rumore";
  return "altro";
}

export default function ArniaDashboard() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [tab, setTab] = useState("settimana");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [arnia, setArnia] = useState(null);
  const [series, setSeries] = useState({ peso: [], temp: [], um: [] });
  const [events, setEvents] = useState([]);

  useEffect(() => {
    let alive = true;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const ar = await restdbGet(`arnie/${id}`);
        if (!alive) return;
        setArnia(ar);

        // Tipi rilevazione (per interpretare sensori)
        let tipMap = new Map();
        try {
          const tips = await restdbGet("tipirilevazione", { h: { $max: 200 } });
          tipMap = new Map((tips || []).map((t) => [t._id, t.tip_descrizione || t.nome || t.descrizione]));
        } catch {
          // opzionale
        }

        // Sensori associati all'arnia: prima prova su "sensori" con FK arn_id,
        // se non c'è nulla prova la tabella ponte "sensoriarnia".
        let sensori = await restdbGet("sensori", { q: { arn_id: id }, h: { $max: 200 } }).catch(() => []);

        if (!sensori?.length) {
          const links = await restdbGet("sensoriarnia", { q: { arn_id: id }, h: { $max: 200 } }).catch(() => []);
          const sensorIds = (links || []).map((l) => l.sen_id).filter(Boolean);
          if (sensorIds.length) {
            sensori = await Promise.all(
              sensorIds.map((sid) => restdbGet(`sensori/${typeof sid === "string" ? sid : sid?._id || sid}`))
            );
          }
        }

        // Classifica sensori per tipo
        const byType = { peso: null, temp: null, um: null };
        for (const s of sensori || []) {
          const raw = s?.sen_tipo;
          const desc = typeof raw === "string" ? raw : tipMap.get(raw?._id || raw) || "";
          const t = pickTypeLabel(desc);
          if (t === "peso" && !byType.peso) byType.peso = s;
          if (t === "temp" && !byType.temp) byType.temp = s;
          if (t === "um" && !byType.um) byType.um = s;
        }

        // Utility per caricare rilevazioni di un sensore
        async function loadRilevazioni(sensor) {
          if (!sensor?._id) return [];
          const rows = await restdbGet("rilevazioni", {
            q: { sen_id: sensor._id },
            h: { $orderby: { ril_dataOra: -1, createdAt: -1 }, $max: 300 },
          }).catch(() => []);

          return (rows || [])
            .map((r) => ({ ...r, _t: parseTime(r) }))
            .filter((r) => r._t)
            .sort((a, b) => a._t - b._t);
        }

        const [pesoRows, tempRows, umRows] = await Promise.all([
          loadRilevazioni(byType.peso),
          loadRilevazioni(byType.temp),
          loadRilevazioni(byType.um),
        ]);

        if (!alive) return;

        const now = new Date();
        const start = new Date(now);
        if (tab === "oggi") {
          start.setHours(0, 0, 0, 0);
        } else if (tab === "mese") {
          start.setDate(start.getDate() - 30);
        } else {
          start.setDate(start.getDate() - 7);
        }

        function toPoints(rows) {
          const filtered = rows.filter((r) => r._t >= start);
          const values = filtered.map((r) => Number(r.ril_dato)).filter((n) => Number.isFinite(n));
          // downsample semplice (max 24 punti)
          if (values.length <= 24) return values;
          const step = Math.ceil(values.length / 24);
          const out = [];
          for (let i = 0; i < values.length; i += step) out.push(values[i]);
          return out;
        }

        setSeries({ peso: toPoints(pesoRows), temp: toPoints(tempRows), um: toPoints(umRows) });

        // Notifiche: se non c'è un FK diretto verso arnia, mostriamo le più recenti.
        const nots = await restdbGet("notifiche", { h: { $orderby: { createdAt: -1 }, $max: 30 } }).catch(() => []);
        if (!alive) return;
        setEvents(nots || []);
      } catch (e) {
        if (!alive) return;
        setError(e?.message || "Errore caricamento arnia");
      } finally {
        if (alive) setLoading(false);
      }
    }

    load();
    return () => {
      alive = false;
    };
  }, [id, tab]);

  const meta = useMemo(() => {
    const piena = arnia?.arn_piena === true || arnia?.arn_piena === "true";
    return {
      location: arnia?.api_id ? "Apiario associato" : "[Location]",
      stato: piena ? "Attenzione" : "OK",
    };
  }, [arnia]);

  function severityMeta(title) {
    const s = (title || "").toLowerCase();
    if (s.includes("allarme") || s.includes("crit") || s.includes("troppo") || s.includes("super")) return { label: "Critico", cls: "badge danger" };
    if (s.includes("atten") || s.includes("avvis") || s.includes("basso") || s.includes("alto")) return { label: "Attenzione", cls: "badge warn" };
    return { label: "Info", cls: "badge ok" };
  }

  if (loading) {
    return (
      <div className="stack">
        <div className="card">
          <div className="h2">Caricamento…</div>
          <div className="muted">Sto leggendo dati e sensori dal database.</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="stack">
        <div className="card">
          <div className="h2">Errore</div>
          <div className="muted" style={{ marginTop: 6 }}>{error}</div>
          <div className="muted small" style={{ marginTop: 10 }}>
            Controlla <code>VITE_RESTDB_API_KEY</code> e che la collezione abbia i campi attesi.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Arnia {id}</div>
            <div className="muted">
              Stato: <span className="pillSoft">{meta.stato}</span>
            </div>
          </div>
          <button className="btn" type="button" onClick={() => navigate(`/arnia/${id}/impostazioni`)}>
            Soglie
          </button>
        </div>

        <div className="segmented mt">
          <button className={"seg" + (tab === "oggi" ? " active" : "")} onClick={() => setTab("oggi")} type="button">Oggi</button>
          <button className={"seg" + (tab === "settimana" ? " active" : "")} onClick={() => setTab("settimana")} type="button">Settimana</button>
          <button className={"seg" + (tab === "mese" ? " active" : "")} onClick={() => setTab("mese")} type="button">Mese</button>
        </div>
      </div>

      <MetricCard title="Peso" unit="Kg" points={series.peso.length ? series.peso : [0]} foot="Suggerimento: controlla variazioni improvvise." />
      <div className="grid2">
        <MetricCard title="Temperatura" unit="°C" points={series.temp.length ? series.temp : [0]} />
        <MetricCard title="Umidità" unit="%" points={series.um.length ? series.um : [0]} />
      </div>

      <div className="listCard">
        <div className="listHeader">
          <div className="h3">Ultimi eventi</div>
          <button className="btn ghost" type="button" onClick={() => navigate("/alerts")}>Vedi tutti</button>
        </div>

        {events?.length ? (
          <div className="notifMini">
            {events.slice(0, 4).map((e) => {
              const m = severityMeta(e.not_titolo || e.title);
              const when = e.not_dataOra || e.not_data || e.createdAt;
              return (
                <div key={e._id || e.id} className="miniItem">
                  <span className={m.cls}>{m.label}</span>
                  <div className="miniText">{e.not_titolo || e.title || "Evento"}</div>
                  <div className="muted small">{when ? new Date(when).toLocaleString() : ""}</div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="emptyState">Nessuna notifica disponibile.</div>
        )}
      </div>
    </div>
  );
}
