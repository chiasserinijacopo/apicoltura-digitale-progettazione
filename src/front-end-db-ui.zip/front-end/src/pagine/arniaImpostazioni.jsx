import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { restdbGet, restdbPatch } from "../lib/restdb.js";

function Stepper({ value, onChange, min = 0, max = 100, unit = "" }) {
  return (
    <div className="stepper">
      <button className="stepBtn" type="button" onClick={() => onChange(Math.max(min, value - 1))} aria-label="Diminuisci">–</button>
      <div className="stepValue">
        {value}
        <span className="stepUnit">{unit}</span>
      </div>
      <button className="stepBtn" type="button" onClick={() => onChange(Math.min(max, value + 1))} aria-label="Aumenta">+</button>
    </div>
  );
}

function classifyType(sensor, typeMap) {
  const t = sensor?.sen_tipo;
  const desc = typeMap?.[t] || t || "";
  const s = String(desc).toLowerCase();
  if (s.includes("temp")) return "temp";
  if (s.includes("peso")) return "peso";
  if (s.includes("umid")) return "um";
  if (s.includes("acqua")) return "acqua";
  if (s.includes("rumore") || s.includes("sound")) return "rumore";
  return "altro";
}

export default function ArniaImpostazioni() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [tMin, setTMin] = useState(18);
  const [tMax, setTMax] = useState(25);
  const [pesoMax, setPesoMax] = useState(50);
  const [notifiche, setNotifiche] = useState(true);

  const [sensorTemp, setSensorTemp] = useState(null);
  const [sensorPeso, setSensorPeso] = useState(null);

  const [typeMap, setTypeMap] = useState({});

  useEffect(() => {
    let alive = true;
    async function load() {
      setLoading(true);
      setError("");
      try {
        const tipi = await restdbGet("tipirilevazione", { h: { $max: 200 } }).catch(() => []);
        const tmap = {};
        (tipi || []).forEach((t) => {
          tmap[t._id] = t.tip_descrizione || t.tip_desc || t.tip_nome;
        });
        if (!alive) return;
        setTypeMap(tmap);

        let sensori = await restdbGet("sensori", { q: { arn_id: id }, h: { $max: 200 } }).catch(() => []);
        if (!sensori?.length) {
          const link = await restdbGet("sensoriarnia", { q: { arn_id: id }, h: { $max: 200 } }).catch(() => []);
          const sIds = (link || []).map((x) => x.sen_id).filter(Boolean);
          if (sIds.length) {
            sensori = await restdbGet("sensori", { q: { _id: { $in: sIds } }, h: { $max: 200 } }).catch(() => []);
          }
        }

        const temp = (sensori || []).find((s) => classifyType(s, tmap) === "temp") || null;
        const peso = (sensori || []).find((s) => classifyType(s, tmap) === "peso") || null;

        if (!alive) return;
        setSensorTemp(temp);
        setSensorPeso(peso);

        if (temp) {
          if (typeof temp.sen_min === "number") setTMin(temp.sen_min);
          if (typeof temp.sen_max === "number") setTMax(temp.sen_max);
        }
        if (peso && typeof peso.sen_max === "number") setPesoMax(peso.sen_max);

        // se nel DB esiste un flag notifiche per arnia/sensore, qui potresti leggerlo.
        setNotifiche(true);
      } catch (e) {
        if (!alive) return;
        setError(e?.message || "Errore caricamento impostazioni");
      } finally {
        if (alive) setLoading(false);
      }
    }
    load();
    return () => {
      alive = false;
    };
  }, [id]);

  const canSave = useMemo(() => !!(sensorTemp || sensorPeso), [sensorTemp, sensorPeso]);

  async function onSave() {
    if (!canSave) {
      setError("Non trovo sensori associati a questa arnia (temperatura/peso). Controlla il DB.");
      return;
    }

    setSaving(true);
    setError("");
    try {
      const ops = [];
      if (sensorTemp) {
        ops.push(
          restdbPatch("sensori", sensorTemp._id, {
            sen_min: Number(tMin),
            sen_max: Number(tMax),
          })
        );
      }
      if (sensorPeso) {
        ops.push(
          restdbPatch("sensori", sensorPeso._id, {
            sen_max: Number(pesoMax),
          })
        );
      }
      await Promise.all(ops);
      // notifiche: non c'è schema certo nel DB → lo lasciamo UI-only.
      navigate(`/arnia/${id}`);
    } catch (e) {
      setError(e?.message || "Errore nel salvataggio");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="stack">
        <div className="card">
          <div className="h2">Caricamento…</div>
          <div className="muted">Sto leggendo sensori e soglie dal database.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Soglie & sensori</div>
            <div className="muted">Arnia {id} • imposta i limiti per gli avvisi.</div>
          </div>
          <button className="btn ghost" type="button" onClick={() => navigate(`/arnia/${id}`)}>
            Chiudi
          </button>
        </div>
        {error ? <div className="statusX show err" style={{ marginTop: 10 }}>{error}</div> : null}
      </div>

      <div className="card">
        <div className="sectionLabel">Temperatura</div>

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Minima</div>
            <div className="muted small">Sotto questa soglia ricevi un avviso.</div>
          </div>
          <Stepper value={tMin} onChange={setTMin} min={0} max={Math.max(0, tMax - 1)} unit="°C" />
        </div>

        <div className="divider" />

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Massima</div>
            <div className="muted small">Sopra questa soglia ricevi un avviso.</div>
          </div>
          <Stepper value={tMax} onChange={setTMax} min={tMin + 1} max={60} unit="°C" />
        </div>

        {!sensorTemp ? <div className="help" style={{ marginTop: 10 }}>Nota: nel DB non ho trovato un sensore di <b>temperatura</b> associato a questa arnia.</div> : null}
      </div>

      <div className="card">
        <div className="sectionLabel">Peso</div>

        <div className="rowBetween">
          <div className="rowText">
            <div className="rowTitle">Massimo</div>
            <div className="muted small">Per rilevare accumuli anomali.</div>
          </div>
          <Stepper value={pesoMax} onChange={setPesoMax} min={0} max={200} unit="Kg" />
        </div>

        {!sensorPeso ? <div className="help" style={{ marginTop: 10 }}>Nota: nel DB non ho trovato un sensore di <b>peso</b> associato a questa arnia.</div> : null}
      </div>

      <div className="card">
        <div className="sectionLabel">Notifiche</div>

        <label className="toggleRow">
          <span className="toggleText">
            <span className="rowTitle">Avvisi arnia</span>
            <span className="muted small">UI-only: schema DB non specificato per questo flag.</span>
          </span>
          <input type="checkbox" checked={notifiche} onChange={(e) => setNotifiche(e.target.checked)} />
          <span className="toggleUI" aria-hidden="true" />
        </label>
      </div>

      <div className="rowGap">
        <button className="btn" type="button" onClick={onSave} disabled={saving}>
          {saving ? "Salvataggio…" : "Salva"}
        </button>
        <button className="btn ghost" type="button" onClick={() => navigate(-1)} disabled={saving}>
          Annulla
        </button>
      </div>
    </div>
  );
}
