import { useEffect, useMemo, useState } from "react";
import MiniChart from "../components/ui/MiniChart.jsx";
import { restdbGet } from "../lib/restdb.js";

function StatCard({ label, value, note }) {
  return (
    <div className="statCard">
      <div className="statLabel">{label}</div>
      <div className="statValue">{value}</div>
      {note ? <div className="statNote">{note}</div> : null}
    </div>
  );
}

function toTime(x) {
  if (!x) return 0;
  const t = Date.parse(x);
  return Number.isFinite(t) ? t : 0;
}

export default function Insights() {
  const [range, setRange] = useState("7g");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [summary, setSummary] = useState({
    arnieTot: 0,
    peso: [],
    temp: [],
    um: [],
    lastSync: null,
  });

  useEffect(() => {
    let alive = true;

    async function run() {
      setLoading(true);
      setError("");
      try {
        const arnie = await restdbGet("arnie", { h: { $max: 200 } });

        // Strategia semplice: prendi le ultime rilevazioni globali e prova a separare per tipo.
        // Se il tuo DB lega le rilevazioni a sensori/tipi, qui avrai valori reali.
        const rilevazioni = await restdbGet("rilevazioni", {
          h: { $orderby: { ril_dataOra: -1, ril_data: -1 }, $max: 200 },
        });

        const now = Date.now();
        const sinceMs = range === "24h" ? 24 * 3600e3 : range === "30g" ? 30 * 86400e3 : 7 * 86400e3;
        const cutoff = now - sinceMs;

        const filtered = (Array.isArray(rilevazioni) ? rilevazioni : []).filter((r) => {
          const t = toTime(r.ril_dataOra || r.ril_data);
          return !t || t >= cutoff;
        });

        // Se nel DB esiste un campo tipo (es. ril_tipo / tip_id), prova a usarlo.
        const byType = { peso: [], temp: [], um: [] };
        for (const r of filtered) {
          const v = Number(r.ril_dato);
          if (!Number.isFinite(v)) continue;

          const tag = String(r.ril_tipo || r.tip_descrizione || r.tip_id || "").toLowerCase();
          if (tag.includes("peso")) byType.peso.push(v);
          else if (tag.includes("temp")) byType.temp.push(v);
          else if (tag.includes("umid")) byType.um.push(v);
        }

        // fallback: se non c'è tipo, mostra una serie generica sulla temperatura (più comune)
        if (!byType.peso.length && !byType.temp.length && !byType.um.length) {
          byType.temp = filtered.map((r) => Number(r.ril_dato)).filter((x) => Number.isFinite(x));
        }

        const last = filtered.length ? filtered[0].ril_dataOra || filtered[0].ril_data : null;

        if (!alive) return;
        setSummary({
          arnieTot: Array.isArray(arnie) ? arnie.length : 0,
          peso: byType.peso.slice().reverse().slice(-24),
          temp: byType.temp.slice().reverse().slice(-24),
          um: byType.um.slice().reverse().slice(-24),
          lastSync: last,
        });
      } catch (e) {
        if (!alive) return;
        setError(e?.message || "Errore caricamento statistiche");
      } finally {
        if (alive) setLoading(false);
      }
    }

    run();
    return () => {
      alive = false;
    };
  }, [range]);

  const info = useMemo(() => {
    const fmt = (arr) => {
      if (!arr?.length) return "—";
      const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
      return avg.toFixed(1);
    };

    return {
      pesoAvg: fmt(summary.peso),
      tempAvg: fmt(summary.temp),
      umAvg: fmt(summary.um),
      last: summary.lastSync ? new Date(summary.lastSync).toLocaleString() : "—",
    };
  }, [summary]);

  return (
    <div className="stack">
      <div className="card">
        <div className="rowBetween">
          <div>
            <div className="h2">Panoramica</div>
            <div className="muted">Dati medi (se disponibili) dal database.</div>
          </div>
          <div className="segmented" role="tablist" aria-label="Intervallo dati">
            <button className={"seg" + (range === "24h" ? " active" : "")} onClick={() => setRange("24h")} type="button">24h</button>
            <button className={"seg" + (range === "7g" ? " active" : "")} onClick={() => setRange("7g")} type="button">7g</button>
            <button className={"seg" + (range === "30g" ? " active" : "")} onClick={() => setRange("30g")} type="button">30g</button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="card"><div className="muted">Caricamento…</div></div>
      ) : error ? (
        <div className="card"><div className="h3">Errore</div><div className="muted" style={{ marginTop: 6 }}>{error}</div></div>
      ) : (
        <>
          <div className="grid2">
            <StatCard label="Arnie nel DB" value={String(summary.arnieTot || 0)} note={`Ultimo dato: ${info.last}`} />
            <StatCard label="Media temperatura" value={`${info.tempAvg}°`} note="Calcolata sulle rilevazioni disponibili" />
          </div>

          <div className="panelCard">
            <div className="panelHeadRow">
              <div className="panelTitle">Peso <span className="panelUnit">Kg</span></div>
              <div className="pillSoft">media</div>
            </div>
            <MiniChart points={(summary.peso && summary.peso.length ? summary.peso : [0])} height={110} />
          </div>

          <div className="grid2">
            <div className="panelCard">
              <div className="panelHeadRow">
                <div className="panelTitle">Temperatura <span className="panelUnit">°C</span></div>
                <div className="pillSoft">media</div>
              </div>
              <MiniChart points={(summary.temp && summary.temp.length ? summary.temp : [0])} height={95} />
            </div>
            <div className="panelCard">
              <div className="panelHeadRow">
                <div className="panelTitle">Umidità <span className="panelUnit">%</span></div>
                <div className="pillSoft">media</div>
              </div>
              <MiniChart points={(summary.um && summary.um.length ? summary.um : [0])} height={95} />
            </div>
          </div>
        </>
      )}
    </div>
  );
}
