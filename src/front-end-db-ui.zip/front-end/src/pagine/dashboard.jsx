import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { restdbGet } from "../lib/restdb.js";

function statusFromHive(h) {
  const piena = h?.arn_piena === true || h?.arn_piena === "true";
  // euristiche: se piena => attenzione, altrimenti ok
  if (piena) return { stato: "Attenzione", salute: "Da controllare", criticita: "Media" };
  return { stato: "OK", salute: "Buono", criticita: "Nessuna" };
}

function statusMeta(stato) {
  if (stato === "Critica") return { cls: "badge danger", dot: "dot danger" };
  if (stato === "Attenzione") return { cls: "badge warn", dot: "dot warn" };
  return { cls: "badge ok", dot: "dot ok" };
}

function formatDateISO(d) {
  if (!d) return null;
  try {
    const dt = new Date(d);
    return new Intl.DateTimeFormat("it-IT", { day: "2-digit", month: "2-digit", year: "2-digit" }).format(dt);
  } catch {
    return String(d);
  }
}

export default function DashboardPrincipale() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [arnieRaw, setArnieRaw] = useState([]);

  useEffect(() => {
    let alive = true;
    async function run() {
      setLoading(true);
      setError("");
      try {
        const items = await restdbGet("arnie", {
          h: { $orderby: { arn_dataInst: -1 }, $max: 100 },
        });
        if (!alive) return;
        setArnieRaw(items || []);
      } catch (e) {
        if (!alive) return;
        setError(e?.message || "Errore nel caricamento delle arnie");
      } finally {
        if (alive) setLoading(false);
      }
    }
    run();
    return () => {
      alive = false;
    };
  }, []);

  const arnie = useMemo(() => {
    return (arnieRaw || []).map((h, idx) => {
      const id = h._id || h.arn_id || String(idx + 1);
      const meta = statusFromHive(h);
      const nome = h.arn_nome || `Arnia ${id}`;
      const pos = h.arn_posizione || h.arn_location || "";
      const label = pos ? `${nome} • ${pos}` : nome;
      const install = formatDateISO(h.arn_dataInst);
      return {
        id,
        nome: label,
        stato: meta.stato,
        salute: meta.salute,
        criticita: meta.criticita,
        last: install ? `Installata: ${install}` : "—",
        _raw: h,
      };
    });
  }, [arnieRaw]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return arnie;
    return arnie.filter((a) => (a.nome + " " + a.id).toLowerCase().includes(s));
  }, [arnie, q]);

  return (
    <div className="stack">
      <div className="card hero">
        <div className="h1">Le tue arnie</div>
        <div className="muted">Seleziona un’arnia per vedere grafici, soglie e notifiche.</div>

        <div className="searchRow">
          <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cerca arnia…" />
          <button className="btn ghost" type="button" onClick={() => alert("Mockup: scan QR")}
            title="Opzionale: scan QR">
            QR
          </button>
        </div>
      </div>

      {loading ? (
        <div className="card">
          <div className="h2">Caricamento…</div>
          <div className="muted">Sto sincronizzando dal database.</div>
        </div>
      ) : null}

      {error ? (
        <div className="card">
          <div className="h2">Errore</div>
          <div className="muted" style={{ marginTop: 6 }}>{error}</div>
          <div className="help">
            Controlla che nel file <code>.env</code> ci sia <code>VITE_RESTDB_API_KEY</code>.
          </div>
        </div>
      ) : null}

      {!loading && !error ? (
        <div className="listCard">
          {filtered.length ? (
            filtered.map((a) => {
              const meta = statusMeta(a.stato);
              return (
                <button key={a.id} className="hiveCard" type="button" onClick={() => navigate(`/arnia/${a.id}`)}>
                  <div className="hiveTop">
                    <div className="hiveName">{a.nome}</div>
                    <span className={meta.cls}><span className={meta.dot} />{a.stato}</span>
                  </div>

                  <div className="gridInfo">
                    <div className="infoItem">
                      <div className="k">Salute</div>
                      <div className="v">{a.salute}</div>
                    </div>
                    <div className="infoItem">
                      <div className="k">Criticità</div>
                      <div className="v">{a.criticita}</div>
                    </div>
                    <div className="infoItem">
                      <div className="k">Info</div>
                      <div className="v">{a.last}</div>
                    </div>
                  </div>

                  <div className="hiveGo">Apri →</div>
                </button>
              );
            })
          ) : (
            <div className="emptyState">
              Nessuna arnia trovata.
              <div className="muted small" style={{ marginTop: 8 }}>
                Aggiungine una con il pulsante “+”.
              </div>
            </div>
          )}
        </div>
      ) : null}

      <button className="fab" type="button" onClick={() => navigate("/aggiungi")} aria-label="Aggiungi arnia">
        +
      </button>
    </div>
  );
}
