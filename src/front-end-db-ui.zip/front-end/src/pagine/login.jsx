import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { restdbGet } from "../lib/restdb.js";
import { setSession } from "../lib/session.js";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [mostra, setMostra] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errore, setErrore] = useState("");

  async function onLogin() {
    const u = username.trim();
    const p = password;
    if (!u || !p) {
      setErrore("Inserisci username e password.");
      return;
    }

    setErrore("");
    setLoading(true);
    try {
      // ⚠️ Prototype auth: cerca in collezione "utenti".
      // Nel DB di progetto i campi esempio sono ute_username e ute_password.
      const items = await restdbGet("utenti", {
        q: { ute_username: u, ute_password: p },
      });

      if (!items?.length) {
        setErrore("Credenziali non valide.");
        return;
      }

      const user = items[0];
      setSession({
        id: user._id,
        username: user.ute_username,
        admin: !!user.ute_admin,
      });

      navigate("/dashboard");
    } catch (e) {
      setErrore(e?.message || "Errore durante il login.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page page-center">
      <div className="phone">
        <div className="loginBrand">
          <div className="brandTop">
            <div className="logoDot" aria-hidden="true" />
            <div className="brandText">APICOLTURA DIGITALE</div>
          </div>
          <div className="brandSub">Accesso</div>
        </div>

        <div className="cardX">
          <div className="cardTitle">Accedi</div>

          <div className="stack" style={{ gap: 10 }}>
            <input
              className="inputX"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setErrore("");
              }}
              placeholder="Username"
              autoComplete="username"
            />

            <div className="inputRow">
              <input
                className="inputX"
                type={mostra ? "text" : "password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrore("");
                }}
                placeholder="Password"
                autoComplete="current-password"
              />

              <button
                className="iconX"
                type="button"
                aria-label="Mostra / Nascondi"
                onClick={() => setMostra((s) => !s)}
                title="Mostra/Nascondi"
              >
                👁
              </button>
            </div>
          </div>

          <button className="btnPrimary" type="button" onClick={onLogin} disabled={loading}>
            {loading ? "ACCESSO..." : "LOGIN"}
          </button>

          <div className={"statusX" + (errore ? " show err" : "")}>{errore}</div>

          <div className="hintX">
            Nota: per far funzionare l’app devi configurare <code>VITE_RESTDB_API_KEY</code> in un file <code>.env</code>.
          </div>
        </div>
      </div>
    </div>
  );
}
