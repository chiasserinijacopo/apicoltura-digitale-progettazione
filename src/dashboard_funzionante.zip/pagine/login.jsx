import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const [apiKey, setApiKey] = useState("");
  const [mostra, setMostra] = useState(false);
  const [stato, setStato] = useState({ visibile: false, errore: false, testo: "" });

  const testoStatusClass = useMemo(() => {
    if (!stato.visibile) return "status";
    return "status show" + (stato.errore ? " err" : "");
  }, [stato]);

  function setStatus(errore, testo) {
    setStato({ visibile: true, errore, testo });
  }

  function clearStatus() {
    setStato({ visibile: false, errore: false, testo: "" });
  }

  function onLogin() {
    const v = (apiKey || "").trim();
    if (!v) {
      setStatus(true, "Inserisci una API key.");
      return;
    }
    if (!v.startsWith("RIGON-ARNIA-")) {
      setStatus(true, "API key non valida.");
      return;
    }
    clearStatus();

    // ✅ Vai alla dashboard React (non dashboard.html)
    navigate("/dashboard");
  }

  return (
    <div className="login-page">
      <div className="wrap">
        <div className="brand-login">
          <div className="logo" aria-hidden="true" />
          <h1>Apicoltura Digitale</h1>
        </div>

        <div className="card login-card">
          <h2 className="title">Accesso</h2>
          <p className="subtitle">Inserisci la API key dell’arnia per aprire la dashboard.</p>

          <label htmlFor="apikey">API Key</label>
          <div className="field">
            <input
              id="apikey"
              type={mostra ? "text" : "password"}
              autoComplete="off"
              placeholder="RIGON-ARNIA-1-••••••••"
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                clearStatus();
              }}
            />

            <button
              className="iconbtn"
              type="button"
              aria-label="Mostra/Nascondi"
              onClick={() => setMostra((s) => !s)}
            >
              {/* eye */}
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
            </button>
          </div>

          <button className="btn" type="button" onClick={onLogin}>
            Login
          </button>

          <div className={testoStatusClass}>{stato.testo}</div>
        </div>

        <div className="hint">
          Esempio: <code>RIGON-ARNIA-1-9F2A</code>
        </div>
      </div>
    </div>
  );
}
