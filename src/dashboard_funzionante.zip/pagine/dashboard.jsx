import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <main className="container" style={{ paddingTop: 24 }}>
      <div className="card">
        <div className="card-inner">
          <div className="row">
            <div className="hive">Dashboard</div>
            <button className="linkbtn" type="button" onClick={() => navigate("/login")}>
              Esci
            </button>
          </div>

          <p className="subtitle" style={{ marginTop: 10 }}>
            Mockup dashboard: qui ci integriamo la dashboard completa.
          </p>
        </div>
      </div>
    </main>
  );
}
