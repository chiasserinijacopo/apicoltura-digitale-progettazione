export default function Dashboard() {
  return (
    <>
      <header className="topbar">
        <div className="brand">
          <div className="logo" />
          <div className="title">
            <h1>Dashboard</h1>
            <span>Monitoraggio Arnie</span>
          </div>
        </div>

        <div className="actions">
          <button className="iconbtn">
            <span className="badge">1</span>
            🔔
          </button>
          <button className="iconbtn">⎋</button>
        </div>
      </header>

      <main className="container">
        <section className="alertbar">
          <div className="alert-left">
            <div className="alert-ic">⚠️</div>
            <div className="alert-text">
              <div className="main">1 alert attivo</div>
              <div className="sub">Mockup — controlla l’arnia</div>
            </div>
          </div>
          <button className="linkbtn">Vedi</button>
        </section>

        <section className="grid">
          {[1, 2, 3].map((id) => (
            <article key={id} className="card">
              <div className="card-inner">
                <div className="row">
                  <div className="hive">Arnia {id}</div>
                  <div className="state-pill">
                    <span className="dot ok" /> OK
                  </div>
                </div>

                <div className="statusline">
                  <div>Stato salute: Buono</div>
                  <div>Criticità: Nessuna</div>
                </div>

                <div className="metrics">
                  <div className="metric">
                    <div className="label">Peso</div>
                    <div className="value">42.3 kg</div>
                  </div>

                  <div className="metric">
                    <div className="label">Temperatura</div>
                    <div className="value">35.1 °C</div>
                  </div>

                  <div className="metric wide">
                    <div className="label">Umidità</div>
                    <div className="value">58 %</div>
                  </div>
                </div>
              </div>

              <div className="card-footer">
                <span>Ultimo aggiornamento: 6 min fa</span>
                <span>Dettagli →</span>
              </div>
            </article>
          ))}
        </section>
      </main>
    </>
  );
}
