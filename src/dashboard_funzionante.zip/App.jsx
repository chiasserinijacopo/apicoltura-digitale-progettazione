import "./app.css";
import Dashboard from "./components/dashboard/Dashboard.jsx";

export default function App() {
  return <Dashboard />;
}
